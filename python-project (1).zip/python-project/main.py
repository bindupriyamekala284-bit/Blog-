# Online Python compiler (interpreter)
# Write and run Python online using this edi
logs = []

while True:
    print("\n===== BLOG PLATFORM =====")
    print("1. Create Blog")
    print("2. View Blogs")
    print("3. Search Blog")
    print("4. Delete Blog")
    print("5. Exit")

    choice = input("Enter your choice: ")

    if choice == "1":
        title = input("Enter Blog Title: ")
        author = input("Enter Author Name: ")
        content = input("Enter Blog Content: ")

        blog = {
            "title": title,
            "author": author,
            "content": content
        }

        blogs.append(blog)
        print("✅ Blog Published Successfully!")

    elif choice == "2":

        if len(blogs) == 0:
            print("No blogs available.")
        else:
            print("\n===== ALL BLOGS =====")

            for i, blog in enumerate(blogs, start=1):
                print(f"\nBlog ID: {i}")
                print("Title :", blog["title"])
                print("Author:", blog["author"])
                print("Content:", blog["content"])

    elif choice == "3":

        search = input("Enter blog title to search: ")

        found = False

        for blog in blogs:
            if search.lower() in blog["title"].lower():
                print("\nBlog Found")
                print("Title :", blog["title"])
                print("Author:", blog["author"])
                print("Content:", blog["content"])
                found = True

        if not found:
            print("Blog not found.")

    elif choice == "4":

        view = len(blogs)

        if view == 0:
            print("No blogs available.")
        else:
            for i, blog in enumerate(blogs, start=1):
                print(i, "-", blog["title"])

            delete_id = int(input("Enter Blog ID to delete: "))

            if 1 <= delete_id <= len(blogs):
                blogs.pop(delete_id - 1)
                print("✅ Blog Deleted Successfully!")
            else:
                print("Invalid Blog ID")

    elif choice == "5":
        print("Thank You for Using Blog Platform")
        break

    else:
        print("Invalid Choice")
